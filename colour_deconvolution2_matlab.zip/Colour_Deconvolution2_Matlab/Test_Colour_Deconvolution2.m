% AUTHORS:      Filippo Piccinini (Email: filippo.piccinini85@gmail.com)
%               Gabriel Landini (Email: g.landini@bham.ac.uk)
%
% DATE:         July 15, 2020
%
% NAME:         Test_Colour_Deconvolution2 (version 1.0)
%
% DESCRIPTION:  This function implements the ImageJ plugin named Colour
%               Deconvolution 2. Please, see the additional references [1]
%               and [2] for additional details.
%
%
% PARAMETERS:
%
% 	ImgR        Red channel (double precision, with values between 0 and
%               255) of the RGB image to be analysed.
%
%   ImgG        Green channel (double precision, with values between 0 and
%               255) of the RGB image to be analysed.
%
%   ImgB        Blue channel (double precision, with values between 0 and
%               255) of the RGB image to be analysed.
%
%   StainingVectorID    ID represents the staining vector to be used 
%               to deconvolve the input RGB image to be analysed.
%               Currently, these are the options available:
%               1  = "H&E"
%               2  = "H&E 2"
%               3  = "H DAB"
%               4  = "H&E DAB"
%               5  = "NBT/BCIP Red Counterstain II"
%               6  = "H DAB NewFuchsin"
%               7  = "H HRP-Green NewFuchsin"
%               8  = "Feulgen LightGreen"
%               9  = "Giemsa"
%               10 = "FastRed FastBlue DAB"
%               11 = "Methyl Green DAB"
%               12 = "H AEC"
%               13 = "Azan-Mallory"
%               14 = "Masson Trichrome"
%               15 = "Alcian Blue & H"
%               16 = "H PAS"
%               17 = "Brilliant_Blue"
%               18 = "AstraBlue Fuchsin"
%               19 = "RGB"
%               20 = "CMY"
%               3x3 matrix = When the StainingVectorID is a 3by3 matrix, 
%                            the single values are considered as the 
%                            vector coefficients for the dyes, in the form
%                            of:
%                                 SM = StainingVectorID;
%                                 MODx = [SM(1,1), SM(1,2), SM(1,3)];
%                                 MODy = [SM(2,1), SM(2,2), SM(2,3)];
%                                 MODz = [SM(3,1), SM(3,2), SM(3,3)];
%                            That is:
%                                 SM = [MODx(1), MODx(2), MODx(3); ...
%                                       MODy(1), MODy(2), MODy(3); ...
%                                       MODz(1), MODz(2), MODz(3)];
%                            For instance, for the "H&E DAB"
%                            (StainingVectorID = 11) the coefficients
%                            are as:
%                                 StainingVectorID=[0.650,0.072,0.268; ...
%                                                   0.704,0.990,0.570; ...
%                                                   0.286,0.105,0.776];
%                            You can also use the ImageJ plugin to
%                            extract values from ROI manually defined.
%                            Note that in ImageJ the coefficients are
%                            named:
%                                 MODx = [R1, R2, R3];
%                                 MODy = [G1, G2, G3];
%                                 MODz = [B1, B2, B3];
%                            and are shown in the Log window when 
%                            checking the dialog option "Show matrices".
%
%
%   DyeToBeRemovedID    ID represents the dye to be removed
%               during the deconvolution step. The output is the RGB
%               image used as input without the contribution of
%               the dye indicated by ChannelToBeRemovedID.
%               Currently, these are the options available:
%               0  = no dyes are removed!
%               1  = the 1st dye of the StainingVector is removed.
%               2  = the 2nd dye of the StainingVector is removed.
%               3  = the 3rd dye of the StainingVector is removed.
%
%   doIcross    This is the parameter called in the ImageJ Colour
%               Deconvolution 2 plugin witht he name of "Crossed product
%               for Colour 3". If it is 1 it computes the cross-product for
%               Colour 3, otherwise computes the Ruifrok's method.
%
% OUTPUT:
%
% 	ImgR_back   Red channel (double precision, with values between 0 and
%               255) of the RGB image generated after removing the
%               contribution of the dye defined by ChannelToBeRemovedID.
%
%   ImgG_back   Green channel (double precision, with values between 0 and
%               255) of the RGB image generated after removing the
%               contribution of the dye defined by ChannelToBeRemovedID.
%
%   ImgB_back   Blue channel (double precision, with values between 0 and
%               255) of the RGB image generated after removing the
%               contribution of the dye defined by ChannelToBeRemovedID.
%
%   Dye01_tran  Mono-channel image (double precision, with values between
%               0 and 255) representing the transmittance of the 1st dye
%               of the StainingVector used to deconvolve the input RGB
%               image. Note: this corresponds to the "-Colour_1"image
%               obtained in ImageJ in greyscale.
%
%   Dye02_tran  Mono-channel image (double precision, with values between
%               0 and 255) representing the transmittance of the 2nd dye
%               of the StainingVector used to deconvolve the input RGB
%               image. Note: this corresponds to the "-Colour_2"image
%               obtained in ImageJ in greyscale.
%
%   Dye03_tran  Mono-channel image (double precision, with values between
%               0 and 255) representing the transmittance of the 3rd dye
%               of the StainingVector used to deconvolve the input RGB
%               image. Note: this corresponds to the "-Colour_3"image
%               obtained in ImageJ in greyscale.
%
%   LUTdye01    Look-Up-Table (double precision, with values between 0
%               and 255) identified by the StainingVectorID to be applyed
%               to the transmittance channel computed for the 1st
%               dye to obtain a colour representation. Note: the
%               colours of the generated image correspond to those in
%               -Colour_1 image typically generated with the ImageJ Colour
%               Deconvolution plugin.
%
%   LUTdye02    Look-Up-Table (double precision, with values between 0
%               and 255) identified by the StainingVectorID to be applyed
%               to the transmittance channel computed for the 2nd
%               dye to obtain a colour representation. Note: the
%               colours of the generated image correspond to those in
%               -Colour_2 image typically generated with the ImageJ Colour
%               Deconvolution plugin.
%
%   LUTdye03    Look-Up-Table (double precision, with values between 0
%               and 255) identified by the StainingVectorID to be applyed
%               to the transmittance channel computed for the 3rd
%               dye to obtain a colour representation. Note: the
%               colours of the generated image correspond to those in
%               -Colour_3 image typically generated with the ImageJ Colour
%               Deconvolution plugin.
%
%   Q3x3Mat     3x3 matrix used to calculate the deconvolution step to 
%               obtain the corresponding transmittance values for
%               [Stain01, Stain02, Stain03].
%
%
% EXAMPLE OF CALL:
%
%   [ImgR_back, ImgG_back, ImgB_back Dye01_transmittance, Dye02_transmittance, Dye03_transmittance, LUTdye01, LUTdye02, LUTdye03, Q3x3Mat] = Colour_Deconvolution2(ImgR, ImgG, ImgB, StainingVectorID, DyeToBeRemovedID);
%
%
% ADDITIONAL REFERENCES:
%
%   [1] Ruifrok, A. C., & Johnston, D. A. (2001). Quantification of histochemical staining by colour deconvolution. Analytical and quantitative cytology and histology, 23(4), 291-299.
%
%   [2] https://blog.bham.ac.uk/intellimic/g-landini-software/colour-deconvolution-2/

% Copyright (C) 2020 Filippo Piccinini and Gabriel Landini
% All rights reserved.
% This program is free software; you can redistribute it and/or modify it 
% under the terms of the GNU General Public License version 3 (or higher) 
% as published by the Free Software Foundation. This program is 
% distributed WITHOUT ANY WARRANTY; without even the implied warranty of 
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
% General Public License for more details.


clc, clear, close all

% INPUT PARAMETERS:
ImgRGB                  = double(imread('example_HandE2.tif'));
StainingVectorID        = 2; %2; %[0.49015734, 0.04615336, 0; 0.76897085, 0.8420684, 0; 0.41040173, 0.5373925, 0]; % "H&E 2"
DyeToBeRemovedID        = 0;
doIcross                = 1;

% IMAGE RESHAPING:
figure, imshow(uint8(ImgRGB), [], 'Border', 'Tight')
ImgR = ImgRGB(:,:,1);
ImgG = ImgRGB(:,:,2);
ImgB = ImgRGB(:,:,3);

% CALL TO THE MAIN FUNCTION:
[ImgR_back, ImgG_back, ImgB_back, Dye01_transmittance, Dye02_transmittance, Dye03_transmittance, LUTdye01, LUTdye02, LUTdye03, Q3x3Mat] = Colour_Deconvolution2(ImgR, ImgG, ImgB, StainingVectorID, DyeToBeRemovedID, doIcross);

% OUTPUT VISUALIZATION: RGB IMAGE RECONSTRUCTED BY REMOVING A DYE
ImgRGB_back(:,:,1) = ImgR_back;
ImgRGB_back(:,:,2) = ImgG_back;
ImgRGB_back(:,:,3) = ImgB_back;
figure, imshow(uint8(ImgRGB_back), 'Border', 'Tight')

% OUTPUT VISUALIZATION: SINGLE DYES: TRANSMITTANCE CHANNELS
figure, imshow(uint8(Dye01_transmittance), 'Border', 'Tight')
figure, imshow(uint8(Dye02_transmittance), 'Border', 'Tight')
figure, imshow(uint8(Dye03_transmittance), 'Border', 'Tight')

% OUTPUT VISUALIZATION: SINGLE DYES: TRANSMITTANCE CHANNELS VISUALISED WITH COLOURS
% Note: these images in colour should be never used for quantitative analysis!
figure, imshow(ind2rgb(uint8(Dye01_transmittance), LUTdye01), 'Border', 'Tight')
figure, imshow(ind2rgb(uint8(Dye02_transmittance), LUTdye02), 'Border', 'Tight')
figure, imshow(ind2rgb(uint8(Dye03_transmittance), LUTdye03), 'Border', 'Tight')

% OUTPUT VISUALIZATION: LUTs IN THE IMAGEJFORMAT
LUTStain01_ImageJ = round(LUTdye01.*255); % Use this to obtain the same values of the ImageJ Colour Deconvolution plugin. Basically, it is a uint8 conversion with rounded values.
LUTStain02_ImageJ = round(LUTdye02.*255); % Use this to obtain the same values of the ImageJ Colour Deconvolution plugin. Basically, it is a uint8 conversion with rounded values.
LUTStain03_ImageJ = round(LUTdye03.*255); % Use this to obtain the same values of the ImageJ Colour Deconvolution plugin. Basically, it is a uint8 conversion with rounded values.
